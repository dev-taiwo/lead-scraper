const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000/api';

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.details || body.error || `Request failed: ${res.status}`);
  }

  return res.json();
}

export function startScrape({ niche, city, maxResults }) {
  return request('/scrape', {
    method: 'POST',
    body: JSON.stringify({ niche, city, maxResults }),
  });
}

export function getScrapeRun(runId) {
  return request(`/scrape/${runId}`);
}

export function getProspects({ niche, city } = {}) {
  const params = new URLSearchParams();
  if (niche) params.set('niche', niche);
  if (city) params.set('city', city);
  const qs = params.toString();
  return request(`/prospects${qs ? `?${qs}` : ''}`);
}

export function setProspectQualified(id, qualified) {
  return request(`/prospects/${id}`, {
    method: 'PATCH',
    body: JSON.stringify({ qualified }),
  });
}

export function exportCsvUrl({ niche, city } = {}) {
  const params = new URLSearchParams();
  if (niche) params.set('niche', niche);
  if (city) params.set('city', city);
  const qs = params.toString();
  return `${API_BASE}/prospects/export/csv${qs ? `?${qs}` : ''}`;
}
